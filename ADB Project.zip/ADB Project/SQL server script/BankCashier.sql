USE Secure_BankDB;
-- Demonstrate cashier access (as BankCashier)
EXECUTE AS USER = 'BankCashier';
SELECT * FROM CashierAccountView;

select * from accounts
update Accounts set balance =500  where AccountNumber='CHK10001';

update Accounts set balance =10000  where AccountNumber='CHK10001';