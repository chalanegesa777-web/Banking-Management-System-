USE Secure_BankDB;
GRANT SELECT ON Customers TO LoanOfficer;

GRANT SELECT ON Accounts TO BankCashier;
GRANT UPDATE(Balance) ON Accounts TO BankCashier;
GRANT INSERT ON Transactions TO BankCashier;
REVOKE UPDATE ON Accounts FROM BankCashier;

REVOKE Select ON Customers FROM LoanOfficer;

REVOKE Select ON Accounts FROM BankClerk;

GRANT INSERT ON Customers TO BankClerk;
GRANT SELECT ON Customers TO BankClerk;

GRANT SELECT ON AuditorTransactionView TO BankAuditor;
GRANT DELETE ON Transactions TO BankAuditor;

GRANT SELECT ON Transactions TO BankAuditor;


select * from Customers;
select * from Accounts;
ALTER TABLE Customers ADD TestColumn INT;
ALTER TABLE Customers DROP COLUMN TestColumn;
