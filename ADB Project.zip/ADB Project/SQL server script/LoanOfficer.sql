USE Secure_BankDB;
select * from Customers;
GRANT SELECT ON Customers TO LoanOfficer;
 
 SELECT * FROM LoanOfficerView WHERE CustomerID=1;

 UPDATE Accounts SET Balance=0 WHERE AccountID=1;

 SELECT SSN FROM Customers WHERE CustomerID=1;