
-- Create database
CREATE DATABASE Secure_BankDB;
USE Secure_BankDB;

-- Create Customers table
CREATE TABLE Customers (
    CustomerID INT PRIMARY KEY IDENTITY(1,1),
    FirstName VARCHAR(50) NOT NULL,
    LastName VARCHAR(50) NOT NULL,
    DateOfBirth DATE NOT NULL,
    SSN VARCHAR(11) UNIQUE NOT NULL,
    Address VARCHAR(100) NOT NULL,
    City VARCHAR(50) NOT NULL,
    State VARCHAR(2) NOT NULL,
    ZipCode VARCHAR(10) NOT NULL,
    PhoneNumber VARCHAR(15) NOT NULL,
    Email VARCHAR(100),
    DateOpened DATE NOT NULL,
    LastUpdated DATETIME NOT NULL DEFAULT GETDATE()
);

-- Insert customers--
INSERT INTO Customers (FirstName, LastName, DateOfBirth, SSN, Address, 
City, State, ZipCode, PhoneNumber, Email, DateOpened)
VALUES 
('Chala', 'Motuma', '1998-05-15', '123-45-6789', '80 Main St', 'Adama', 
'OR', '1000', '+251945383833', 'chalamotuma@email.com', '2020-01-10'),
('Sara', 'Birhanu', '1975-08-22', '234-56-7890', '456 Bole', 'Addis Ababa', 
'AA', '1000', '+251944567776', 'sarabirhanu@email.com', '2019-03-15'),
('Megersa ', 'Wako', '1990-11-30', '345-67-8901', '789 Piassa', 'Addis Ababa', 
'AD', '1000', '+251945383008', 'megersawako@email.com', '2021-02-20'),
('Ermiyas', 'Bekele', '1988-04-05', '456-78-9012', '321 bishoftu ', 'Hawasa', 
'SD', '0000', '+251982763509', 'ermiyasbekele@email.com', '2018-07-12'),
('Dawit', 'Jamal', '1972-09-18', '567-89-0123', '654 moyale', 'Moyale', 
'KE', '0000', '+251900957431', 'dawitjamal@email.com', '2017-05-25'),
('Jalane', 'Gadisa', '1985-12-25', '678-90-1234', '987 Gefersa', 'Holeta', 
'OR', '0000', '+251967873452', 'jalanegadisa@email.com', '2020-11-30'),
('Regasa', 'Mulata', '1978-06-08', '789-01-2345', '159 Bekoji', 'Bekoji', 
'AR', '0000', '+251988773322', 'regasamulata@email.com', '2019-09-14'),
('Jagama', 'Dereje', '1992-03-12', '890-12-3456', '753 Bahir Dar', 'Bahir Dar', 
'AM', '0000', '+251999999900', 'jagamadereje@email.com', '2021-04-05'),
('Wakuma', 'Roba', '1965-07-20', '901-23-4567', '426 Yabelo', 'Yabelo', 
'BR', '0000', '+251900003476', 'wakumaroba@email.com', '2016-08-18'),
('Aman', 'Martu', '1983-10-03', '012-34-5678', '864 Hararghe', 'Ciro', 
'HA', '0000', '+251998430222', 'amanmartu@email.com', '2018-12-22');
select * from Customers;

-- Create Accounts table
CREATE TABLE Accounts (
    AccountID INT PRIMARY KEY IDENTITY(1,1),
    CustomerID INT NOT NULL,
    AccountType VARCHAR(20) NOT NULL, -- Checking, Savings, Loan, etc.
    AccountNumber VARCHAR(20) UNIQUE NOT NULL,
    Balance DECIMAL(15,2) NOT NULL DEFAULT 0.00,
    InterestRate DECIMAL(5,2),
    OpenDate DATE NOT NULL,
    Status VARCHAR(15) NOT NULL DEFAULT 'Active',
    LastActivityDate DATETIME NOT NULL DEFAULT GETDATE(),
    FOREIGN KEY (CustomerID) REFERENCES Customers(CustomerID)
);

-- Insert accounts
INSERT INTO Accounts (CustomerID, AccountType, AccountNumber, Balance, InterestRate, OpenDate)
VALUES 
(1, 'Checking', 'CHK10001', 2500.00, 0.01, '2020-01-10'),
(1, 'Savings', 'SAV10002', 15000.00, 1.25, '2020-01-10'),
(2, 'Checking', 'CHK20001', 1800.00, 0.01, '2019-03-15'),
(3, 'Checking', 'CHK30001', 3200.00, 0.01, '2021-02-20'),
(3, 'Savings', 'SAV30002', 8000.00, 1.25, '2021-02-20'),
(4, 'Checking', 'CHK40001', 4200.00, 0.01, '2018-07-12'),
(5, 'Checking', 'CHK50001', 1500.00, 0.01, '2017-05-25'),
(5, 'Savings', 'SAV50002', 25000.00, 1.25, '2017-05-25'),
(6, 'Checking', 'CHK60001', 3600.00, 0.01, '2020-11-30'),
(7, 'Checking', 'CHK70001', 2900.00, 0.01, '2019-09-14'),
(8, 'Checking', 'CHK80001', 5100.00, 0.01, '2021-04-05'),
(9, 'Checking', 'CHK90001', 1200.00, 0.01, '2016-08-18'),
(10, 'Checking', 'CHK00001', 4700.00, 0.01, '2018-12-22'),
(10, 'Savings', 'SAV00002', 18000.00, 1.25, '2018-12-22');
select * from Accounts;

-- Create Transactions table
CREATE TABLE Transactions (
    TransactionID INT PRIMARY KEY IDENTITY(1,1),
    AccountID INT NOT NULL,
    TransactionType VARCHAR(20) NOT NULL, -- Deposit, Withdrawal, Transfer, etc.
    Amount DECIMAL(15,2) NOT NULL,
    TransactionDate DATETIME NOT NULL DEFAULT GETDATE(),
    Description VARCHAR(100),
    EmployeeID INT,
    FOREIGN KEY (AccountID) REFERENCES Accounts(AccountID)
);
       --Insert into Transaction
INSERT INTO Transactions (AccountID, TransactionType, Amount, Description, EmployeeID)
VALUES 
(1, 'Deposit', 500.00, 'Initial deposit', 1),
(2, 'Deposit', 10000.00, 'Initial deposit', 1),
(3, 'Deposit', 1000.00, 'Initial deposit', 1),
(4, 'Deposit', 2000.00, 'Initial deposit', 1),
(5, 'Deposit', 5000.00, 'Initial deposit', 1),
(1, 'Withdrawal', 200.00, 'ATM withdrawal', 3),
(2, 'Interest', 15.00, 'Monthly interest', NULL),
(3, 'Deposit', 800.00, 'Paycheck deposit', 3),
(4, 'Withdrawal', 300.00, 'Check #1001', 3),
(5, 'Interest', 10.00, 'Monthly interest', NULL);
select * from Transactions;

-- Create Employees table
CREATE TABLE Employees (
    EmployeeID INT PRIMARY KEY IDENTITY(1,1),
    FirstName VARCHAR(50) NOT NULL,
    LastName VARCHAR(50) NOT NULL,
    Position VARCHAR(50) NOT NULL,
    HireDate DATE NOT NULL,
    Email VARCHAR(100) NOT NULL,
    PhoneNumber VARCHAR(15) NOT NULL
);

-- Insert employees
INSERT INTO Employees (FirstName, LastName, Position, HireDate, Email, PhoneNumber)
VALUES 
('James', 'Wilson', 'Manager', '2015-01-15', 'james.wilson@bank.com', '555-111-2222'),
('Lisa', 'Taylor', 'Clerk', '2018-03-10', 'lisa.taylor@bank.com', '555-222-3333'),
('Thomas', 'Anderson', 'Cashier', '2019-05-20', 'thomas.anderson@bank.com', '555-333-4444'),
('Nancy', 'Thomas', 'Loan Officer', '2017-07-12', 'nancy.thomas@bank.com', '555-444-5555'),
('Daniel', 'Jackson', 'Auditor', '2016-09-25', 'daniel.jackson@bank.com', '555-555-6666'); 
select * from Employees;

-- Create UserRoles table
CREATE TABLE UserRoles (
    RoleID INT PRIMARY KEY IDENTITY(1,1),
    RoleName VARCHAR(50) NOT NULL UNIQUE,
    Description VARCHAR(200) NOT NULL
);

-- Insert roles
INSERT INTO UserRoles (RoleName, Description) VALUES 
('Manager', 'Database administrator with full access'),
('Clerk', 'Handles customer information and account maintenance'),
('Cashier', 'Processes deposits and withdrawals'),
('LoanOfficer', 'Manages loan accounts and applications'),
('Auditor', 'Reviews transactions and has delete permissions');
select * from UserRoles;

   --Create Loans table
CREATE TABLE Loans (
    loan_id INT PRIMARY KEY IDENTITY(1,1),
    customer_id INT,
    amount DECIMAL(18,2),
    interest_rate DECIMAL(5,2),
    start_date DATETIME,
    end_date DATETIME,
    status NVARCHAR(20),
    FOREIGN KEY (customer_id) REFERENCES Customers(customerID)
);
    -- Insert Loans
INSERT INTO Loans (customer_id, amount, interest_rate, start_date, end_date, status) VALUES
(1, 50000.00, 5.0, GETDATE(), DATEADD(YEAR, 5, GETDATE()), 'Approved'),
(2, 30000.00, 4.5, GETDATE(), DATEADD(YEAR, 3, GETDATE()), 'Pending');
Select * from Loans;
COMMIT;
 
--Create login for manager (DBA)
CREATE LOGIN BankManager WITH PASSWORD = 'SecureBank@123';
CREATE USER BankManager FOR LOGIN BankManager;
ALTER ROLE db_owner ADD MEMBER BankManager;

-- Create login for clerk
CREATE LOGIN BankClerk WITH PASSWORD = 'Clerk@Secure123';
CREATE USER BankClerk FOR LOGIN BankClerk;

-- Create login for cashier
CREATE LOGIN BankCashier WITH PASSWORD = 'Cashier@Secure123';
CREATE USER BankCashier FOR LOGIN BankCashier;

-- Create login for loan officer
CREATE LOGIN LoanOfficer WITH PASSWORD = 'Loan@Secure123';
CREATE USER LoanOfficer FOR LOGIN LoanOfficer;

-- Create login for auditor
CREATE LOGIN BankAuditor WITH PASSWORD = 'Auditor@Secure123';
CREATE USER BankAuditor FOR LOGIN BankAuditor;

-- 5. Grant Permissions
-- BankManager: Full access
GRANT SELECT, INSERT, UPDATE, DELETE ON Customers TO BankManager WITH GRANT OPTION;
GRANT SELECT, INSERT, UPDATE, DELETE ON Accounts TO BankManager WITH GRANT OPTION;
GRANT SELECT, INSERT, UPDATE, DELETE ON Transactions TO BankManager WITH GRANT OPTION;
GRANT SELECT, INSERT, UPDATE, DELETE ON Loans TO BankManager WITH GRANT OPTION;

   --Create Role-Specific Views and Permission
-- Clerk view (can see customer info but not SSN)
CREATE VIEW ClerkCustomerView AS
SELECT CustomerID, FirstName, LastName, DateOfBirth, Address, City, State, ZipCode, PhoneNumber, Email, DateOpened
FROM Customers;

-- Grant permissions to clerk
GRANT SELECT ON ClerkCustomerView TO BankClerk;
GRANT SELECT, UPDATE ON Accounts TO BankClerk;

-- Cashier view (can see account balances and process transactions)
CREATE VIEW CashierAccountView AS
SELECT a.AccountID, a.AccountNumber, a.AccountType, a.Balance, c.FirstName, c.LastName
FROM Accounts a
JOIN Customers c ON a.CustomerID = c.CustomerID;

-- Grant permissions to cashier
GRANT SELECT ON CashierAccountView TO BankCashier;
GRANT INSERT ON Transactions TO BankCashier;
GRANT UPDATE (Balance) ON Accounts TO BankCashier;

-- Loan officer view (can see customer financial info)
CREATE VIEW LoanOfficerView AS
SELECT c.CustomerID, c.FirstName, c.LastName, c.DateOfBirth, 
������ a.AccountID, a.AccountType, a.Balance, a.InterestRate, a.OpenDate
FROM Customers c
JOIN Accounts a ON c.CustomerID = a.CustomerID;

-- Grant permissions to loan officer
GRANT SELECT ON LoanOfficerView TO LoanOfficer;


-- Auditor view (can see all transactions)
CREATE VIEW AuditorTransactionView AS
SELECT t.TransactionID, t.TransactionDate, t.TransactionType, t.Amount, t.Description,
������ a.AccountNumber, a.AccountType, c.FirstName + ' ' + c.LastName AS CustomerName,
������ e.FirstName + ' ' + e.LastName AS EmployeeName
FROM Transactions t
JOIN Accounts a ON t.AccountID = a.AccountID
JOIN Customers c ON a.CustomerID = c.CustomerID
LEFT JOIN Employees e ON t.EmployeeID = e.EmployeeID;

-- Grant permissions to auditor
GRANT SELECT ON AuditorTransactionView TO BankAuditor;
GRANT DELETE ON Transactions TO BankAuditor;

-- Demonstrate clerk access (as BankClerk)
EXECUTE AS USER = 'BankClerk';
SELECT * FROM ClerkCustomerView;
SELECT * FROM Accounts; -- Should fail (no direct access)
REVERT;

-- Demonstrate cashier access (as BankCashier)
EXECUTE AS USER = 'BankCashier';
SELECT * FROM CashierAccountView;

REVOKE DELETE ON Customers FROM BankAuditor;

-- Attempt to update balance (allowed)
UPDATE Accounts SET Balance = Balance + 100 WHERE AccountID = 1;
REVERT;

-- Demonstrate auditor access (as BankAuditor)
EXECUTE AS USER = 'BankAuditor';
SELECT * FROM AuditorTransactionView;
-- Delete a transaction (allowed)
DELETE FROM Transactions WHERE TransactionID = 10;
REVERT;





































