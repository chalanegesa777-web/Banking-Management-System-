USE Secure_BankDB;
SELECT * FROM AuditorTransactionView where Amount>2500;

SELECT * FROM Transactions;
DELETE FROM Transactions where TransactionID=1;