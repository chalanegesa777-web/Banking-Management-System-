USE Secure_BankDB;
--Demonstrate clerk access (as BankClerk)
EXECUTE AS USER = 'BankClerk';
SELECT * FROM ClerkCustomerView;
SELECT * FROM Accounts; -- Should fail (no direct access)
REVERT

SELECT * FROM Accounts;

INSERT INTO Customers (FirstName, LastName, DateOfBirth, SSN, Address, 
City, State, ZipCode, PhoneNumber, Email, DateOpened)
VALUES 
('Chaltu', 'Megersa', '1998-05-5', '13-45-6789', '8 Main St', 'Ambo', 
'OR', '0000', '+251978654321', 'chaltumegersa@email.com', '2022-01-10');

SELECT * FROM Customers;
